export class AppSettings {
   public static API_STARTPOINT='https://safedev.cybermediaservices.in'; 
}
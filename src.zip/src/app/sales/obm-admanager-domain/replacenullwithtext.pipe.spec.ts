import { ReplacenullwithtextPipe } from './replacenullwithtext.pipe';

describe('ReplacenullwithtextPipe', () => {
  it('create an instance', () => {
    const pipe = new ReplacenullwithtextPipe();
    expect(pipe).toBeTruthy();
  });
});

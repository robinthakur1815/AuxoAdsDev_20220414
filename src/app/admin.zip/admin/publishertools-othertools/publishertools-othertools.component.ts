import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';
import { MatTableDataSource } from '@angular/material/table';
import { BreakpointObserver } from '@angular/cdk/layout';
@Component({
  selector: 'app-publishertools-othertools',
  templateUrl: './publishertools-othertools.component.html',
  styleUrls: ['./publishertools-othertools.component.scss']
})

  export class PublisherToolsOtherToolsComponent  {
   
}

